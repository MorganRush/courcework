CREATE FUNCTION culc_rating()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  BEGIN

    UPDATE "Команда" SET "Рейтинг" = 1 +
    (SELECT AVG("Общий рейтинг") FROM "Игровые характеристики" WHERE "ID_Игрока" IN
      (SELECT "ID_Игрока" FROM "Контракты" WHERE "Команда"."ID_Команды" = "Контракты"."ID_Команды"));

    RETURN NEW;
  END;
$$;

